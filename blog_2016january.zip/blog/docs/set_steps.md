# Steps To Set Up My First Blog

*Modified on 2016.1.1*

![My_Web](image/My_Blog.png)

## Step 1:

-  Install the Python3 by using "apt-get install python3"/downloading from the website(on Windows)

## Step 2:

-  Install the mkdocs by using "python3 -m pip install mkdocs "

## Step 3:

-  Using "mkdocs new my_blog_name"

## Step 4:

-  Start the Server by using "mkdocs serve -a 0.0.0.0:80"


## Just Enjoy it!!! 

