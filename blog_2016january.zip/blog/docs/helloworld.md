# Hello My Blog

*Modified On 2016.1.1*

--------

My Blog has already been set up on the server by using "mkdocs" in my lab.

Here are the features of the server:


![hello](image/server_pc.png)

> [if you are interested in how to build your own Blog, CLICK HERE](../set_steps)
