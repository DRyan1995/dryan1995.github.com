*Set On 2016.1.4*

**This time table is made for the review of final examination.**

+ 8:00 - 8:20

> Getting up and Making up...

+ 8:30 - 9:00

> Breakfast and on the way...

+ 9:00 - 9:20

> Arriving at the lab

+ 9:30 - 10:30

> Reviewing for the IC

+ 10:30 -11:30

> Reviewing for the Simiconductor

+ 11:30 - 12:30

> Having lunch and have a rest

+ 12:30 - 14:00

> Do what I want

+ 14:00 - 15:30

> Review for IC

+ 15:40 - 17:00

> Review for Simiconductor

+ 17:00 - 19:00

> Dinner and having a rest

+ 19:00 - 20:00

> Review for the practical experiment

+ 20:00 - 20:45

> Review IC

+ 20:50 - 21:40

> Review Simiconductor

+ 21:50 - 22:10

> Prepare to go home

+ 22:30 - 00:30

> Shower and Blog.