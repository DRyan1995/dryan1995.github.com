
#Port Management On the Lab Serveri7

> + port 6666 -> 192.168.0.155:3389

> *used for Microsoft Remote Contrl*

> + port 8888 -> 192.169.0.160:88

> *used for accessing my blog on the ubuntu server*

> + port 22 -> 192.168.0.160:22

> *used for ssh accessing to the ubuntu on server*

> + port 1000 -> 192.168.0.160:1000

> *used for the http server for sharing folders.*

> + port 54321 -> 192.168.0.161:54321

> *used for the romote desktop for my own os Win7 on serveri7*
