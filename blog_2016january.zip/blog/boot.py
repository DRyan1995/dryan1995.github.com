# coding=utf-8

import os

os.chdir(r"C:/Users/Ryan/Desktop/blog")
os.popen(r"mkdocs serve -a 0.0.0.0:80")